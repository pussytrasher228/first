-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Апр 06 2021 г., 17:04
-- Версия сервера: 10.5.8-MariaDB
-- Версия PHP: 7.4.14

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `cr3example`
--

-- --------------------------------------------------------

--
-- Структура таблицы `catlog_item`
--

CREATE TABLE `catlog_item` (
  `item_id` int(11) NOT NULL,
  `item_name` varchar(50) NOT NULL,
  `description` varchar(500) NOT NULL,
  `price` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `catlog_item`
--

INSERT INTO `catlog_item` (`item_id`, `item_name`, `description`, `price`) VALUES
(2, 'Товар 1', 'описание товара 1', 10),
(3, 'Товар 2', 'описание товара 2', 20),
(4, 'Товар 3', 'описание товара 3', 30),
(5, 'Товар 4', 'описание товара 4', 40);
(6, 'Товар 5', 'описание товара 5', 10),
(7, 'Товар 6', 'описание товара 6', 20),
(8, 'Товар 7', 'описание товара 7', 30),
(9, 'Товар 8', 'описание товара 8', 40);
(10, 'Товар 9', 'описание товара 9', 10),
(11, 'Товар 10', 'описание товара 10', 20),
(12, 'Товар 11', 'описание товара 11', 30),
(13, 'Товар 12', 'описание товара 12', 40);
(14, 'Товар 13', 'описание товара 13', 10),
(15, 'Товар 14', 'описание товара 14', 20),
(16, 'Товар 15', 'описание товара 15', 30),

-- --------------------------------------------------------

--
-- Структура таблицы `client`
--

CREATE TABLE `client` (
  `ID` int(11) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `birthdate` date NOT NULL,
  `address` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `client`
--

INSERT INTO `client` (`ID`, `lastname`, `firstname`, `birthdate`, `address`) VALUES
(1, 'Иванов', 'Иван', '1980-01-01', 'ул. Ленина д.103 кв. 55 г. Пермь'),
(2, 'Петров', 'Петр', '1984-01-01', NULL),
(3, 'Смирнова', 'Наталья', '1984-02-01', NULL),
(4, 'Кузнецова', 'Светлана', '1983-01-01', NULL),
(5, 'Сидоров', 'Иван', '1984-01-01', NULL),
(6, 'Иванов', 'Петр', '1985-01-01', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `order`
--

CREATE TABLE `order` (
  `oid` int(11) NOT NULL,
  `order_num` varchar(10) NOT NULL,
  `order_date` date NOT NULL,
  `client_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `order`
--

INSERT INTO `order` (`oid`, `order_num`, `order_date`, `client_id`) VALUES
(1, '01/21', '2021-03-15', 1),
(2, '02/21', '2021-03-15', 2),
(3, '03/21', '2021-03-16', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `order_item_rel`
--

CREATE TABLE `order_item_rel` (
  `oid` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `order_item_rel`
--

INSERT INTO `order_item_rel` (`oid`, `item_id`, `quantity`) VALUES
(1, 2, 2),
(1, 4, 5),
(1, 5, 1),
(2, 2, 10),
(3, 3, 3),
(3, 4, 10);

-- --------------------------------------------------------

--
-- Структура таблицы `system_pages`
--

CREATE TABLE `system_pages` (
  `id` int(11) NOT NULL,
  `page` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `controller` varchar(50) NOT NULL,
  `handler` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `system_pages`
--

INSERT INTO `system_pages` (`id`, `page`, `description`, `controller`, `handler`) VALUES
(1, 'listorders', 'Получение списка заказов', 'OrderClass', 'list'),
(2, 'addorder', 'Добавление заказа', 'OrderClass', 'add'),
(3, 'editorder', 'Редактирование заказа', 'OrderClass', 'edit'),
(4, 'deleteorder', 'Удаление заказа', 'OrderClass', 'delete');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `catlog_item`
--
ALTER TABLE `catlog_item`
  ADD PRIMARY KEY (`item_id`);

--
-- Индексы таблицы `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`oid`),
  ADD KEY `client_id` (`client_id`);

--
-- Индексы таблицы `order_item_rel`
--
ALTER TABLE `order_item_rel`
  ADD PRIMARY KEY (`oid`,`item_id`),
  ADD KEY `item_id` (`item_id`);

--
-- Индексы таблицы `system_pages`
--
ALTER TABLE `system_pages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `page` (`page`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `catlog_item`
--
ALTER TABLE `catlog_item`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `client`
--
ALTER TABLE `client`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `order`
--
ALTER TABLE `order`
  MODIFY `oid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `system_pages`
--
ALTER TABLE `system_pages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `order`
--
ALTER TABLE `order`
  ADD CONSTRAINT `order_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `client` (`ID`);

--
-- Ограничения внешнего ключа таблицы `order_item_rel`
--
ALTER TABLE `order_item_rel`
  ADD CONSTRAINT `order_item_rel_ibfk_1` FOREIGN KEY (`oid`) REFERENCES `order` (`oid`),
  ADD CONSTRAINT `order_item_rel_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `catlog_item` (`item_id`) ON UPDATE CASCADE;
SET FOREIGN_KEY_CHECKS=1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
