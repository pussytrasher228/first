<?php

namespace MyApp\Controller;
use MyApp\Controller\DBClass;
use PDO;
use Exception;

class OrderClass extends DBClass
{
    //В начале каждого метода ведем журналирование

    /**
     * Запрос на лист всех записей
     * с проверкой нахождения ключа в массиве фильтров
     * @param array $params
     * @param array $filterParams
     * @return array
     */
    public function listing( $params = [] ,$filterParams = [] )
    {
        $this->logger->logEvent('list', __FILE__, __LINE__, __FUNCTION__);
        $queryParams = $params; 
        $query = "SELECT `order`.`oid`, `order`.`order_num`, `order`.`order_date`,
                    CONCAT(`client`.`lastname`, ' ', `client`.`firstname`) as `name`,
                    Count(*) as `count`, SUM(oir.quantity*catlog_item.price) as `sum`
                    FROM `client`, `order`, `catlog_item`
                    LEFT JOIN order_item_rel oir on catlog_item.item_id = oir.item_id
                    WHERE oir.oid =`order`.oid and `client`.ID = `order`.client_id
            ";

        if (array_key_exists("client_id", $filterParams)) {
            $query = $query." and  `order`.client_id = ?";
            $queryParams[] = $filterParams["client_id"];
        }

        if (array_key_exists("order_num", $filterParams)) {
            $query = $query." and `order`.`order_num` = ?";
            $queryParams[] = $filterParams["order_num"];
        }

        if (array_key_exists("order_date", $filterParams)) {
            $query = $query." and `order`.`order_date` = ?";
            $queryParams[] = $filterParams["order_date"];
        }

        $query .= " group by `order`.oid ";

        $data = $this->queryFetchAll($query, $queryParams);
        $names = $this->listnames();

        return ['names'=> $names ,'data' => $data];
    }

    /**
     * Запрос на лист информации о заказах
     * @param array $params
     * @return array
     */
    public function infoOrder(  $params = []  )
    {
        $this->logger->logEvent('list orderInfo', __FILE__, __LINE__, __FUNCTION__);
        $queryOrder = "SELECT `oir`.oid, `o`.order_num, `o`.order_date, CONCAT(`c`.`lastname`, ' ', `c`.`firstname`) as `name`,
                        COUNT(*) as `count`, SUM(oir.quantity*catlog_item.price) as `sum`
                        FROM `catlog_item`
                        LEFT JOIN order_item_rel oir on catlog_item.item_id = oir.item_id
                        LEFT JOIN `order` o on oir.oid = o.oid
                        LEFT JOIN `client` c on o.client_id = c.ID
                        WHERE o.oid = ?";

        $queryItems = "SELECT `oir`.item_id, `catlog_item`.item_name, `oir`.quantity, `catlog_item`.description, `catlog_item`.price
                        FROM `catlog_item`
                        LEFT JOIN order_item_rel oir on catlog_item.item_id = oir.item_id
                        WHERE oir.oid = ?";

        $queryParams[] = $params["oid"];
        $dataOrder = $this->queryFetchAll($queryOrder, $queryParams);
        $dataItems = $this->queryFetchAll($queryItems, $queryParams);

        return ['dataorder' => $dataOrder,'dataitems' => $dataItems];
    }

    /**
     * Запрос на лист клиентов
     * с проверкой нахождения ключа в массиве фильтров
     * @param array $params
     * @param array $filterParams
     * @return array
     */
    public function clientsListing($params = [] ,$filterParams = [])
    {
        // implement list
        $this->logger->logEvent('list clients', __FILE__, __LINE__, __FUNCTION__);
        $queryParams = $params; 
        $query = "SELECT `client`.ID, `client`.lastname, `client`.firstname, `client`.birthdate,
                    `client`.address, COUNT(`oir`.oid) as count,
                    SUM(`ci`.price * `oir`.quantity) as total_sum
                    FROM `client`
                    LEFT JOIN `order` o on client.ID = o.client_id
                    LEFT JOIN `order_item_rel` oir on o.oid = oir.oid
                    LEFT JOIN `catlog_item` ci on oir.item_id = ci.item_id
                    WHERE 1=1 ";

        if (array_key_exists("lastname", $filterParams)) {
            $query = $query." and `client`.lastname = ?";
            array_push($queryParams,$filterParams["lastname"]);
        }

        if (array_key_exists("birthyear", $filterParams)) {
            $query = $query." and YEAR(`client`.birthdate) = ?";
            array_push($queryParams,$filterParams["birthyear"]);
        }

        $query .= " group by ID";
        $data = $this->queryFetchAll($query, $queryParams);

        return ['data' => $data];
    }

    /**
     * Запрос на лист каталога
     * с левым джоином деталей заказа
     * и с проверкой нахождения ключа в массиве фильтров
     * @param array $params
     * @param array $filterParams
     * @return array
     */
    public function catalogListing( $params = [] ,$filterParams = [])
    {
        $this->logger->logEvent('list catalog join', __FILE__, __LINE__, __FUNCTION__);
        $queryParams = $params; 
        $query = "SELECT `catlog_item`.item_id, `catlog_item`.item_name, `catlog_item`.description,
                    `catlog_item`.price, COUNT(*) as count
                    FROM `catlog_item`
                    LEFT JOIN order_item_rel oir on catlog_item.item_id = oir.item_id WHERE 1=1";

        if (array_key_exists("item_name", $filterParams)) {
            $query = $query." and `catlog_item`.item_name = ?";
            array_push($queryParams,$filterParams["item_name"]);
        }

        if (array_key_exists("description", $filterParams)) {
            $query = $query." and `catlog_item`.description = ?";
            array_push($queryParams,$filterParams["description"]);
        }

        if (array_key_exists("minprice", $filterParams)) {
            $query = $query." and `catlog_item`.price >= ?";
            array_push($queryParams,$filterParams["minprice"]);
        }

        if (array_key_exists("maxprice", $filterParams)){
            $query = $query." and `catlog_item`.price <= ?";
            array_push($queryParams,$filterParams["maxprice"]);
        }

        $query = $query." group by `catlog_item`.`item_id`";
        $data = $this->queryFetchAll($query, $queryParams);

        return ['data' => $data];
    }

    /**
     * Запрос на добавление заказа
     * @param $queryParams
     * @return int
     */
    public function orderAdd($queryParams)
    {
        var_dump($queryParams);
        $this->logger->logEvent('add order', __FILE__, __LINE__, __FUNCTION__);
        $query = "INSERT INTO `order` (`order_num`, `order_date`, `client_id`)
                    VALUES (?, ?, ?);";
        $this->queryFetchAll($query, $queryParams);

        return 1;
    }

    /**
     * Запрос на добавление деталей заказа
     * с проверкой на наличие в бд
     * при наличии мы обновляем деталями из входных данных
     * @param array $params
     */
    public function orderItemAdd($params = [])
    {
        $this->logger->logEvent('add orderItem', __FILE__, __LINE__, __FUNCTION__);
        $queryParams = $params;
        $queryParamsif = $params;
        unset($queryParamsif[2]);
        $queryif = "SELECT * FROM `order_item_rel` WHERE `oid` = ? and `item_id` = ?";
        $check = $this->queryFetchAll($queryif, $queryParamsif);
        if (!empty($check)) {
            $queryParams[0] = (string)((int)$queryParams[2]+(int)$check[0]['quantity']);
            var_dump($queryParams[0]);
            var_dump($queryParams[2]);

            $queryParams[2] = $queryParamsif[0];
            $query = "UPDATE `order_item_rel` SET `quantity` = ? WHERE `item_id` = ? and `oid` = ?;";
        $this->queryFetchAll($query, $queryParams);
        } else {
            $query = "INSERT INTO `order_item_rel` (`oid`, `item_id`, `quantity`)
            VALUES (?, ?, ?);";
            $this->queryFetchAll($query, $queryParams);
        }

    }

    /**
     * Запрос на добавление клиента
     * @param array $params
     */
    public function clientsAdd($params = [] )
    {
        $this->logger->logEvent('add clients', __FILE__, __LINE__, __FUNCTION__);
        $queryParams = $params;
        $query = "INSERT INTO `client` (`lastname`, `firstname`, `birthdate`,`address`)
                    VALUES (?, ?, ?, ?);";
        $this->queryFetchAll($query, $queryParams);
    }

    /**
     * Запрос на добавление в каталог
     * @param array $params
     */
    public function catalogItemAdd($params = [])
    {
        $this->logger->logEvent('add catalogItem', __FILE__, __LINE__, __FUNCTION__);
        $queryParams = $params;
        $query = " INSERT INTO `catlog_item` (`item_name`, `description`, `price`)
                    VALUES (?, ?, ?);";
        $this->queryFetchAll($query, $queryParams);
    }

    /**
     * Запрос на редактирование заказа
     *
     * @param array $params
     */
     public function orderEdit($params = [])
     {
        $this->logger->logEvent('edit order', __FILE__, __LINE__, __FUNCTION__);
        $queryParams = $params;
        $query = "UPDATE `order`
                  SET `order_num` = ?, `order_date` = ?, `client_id` = ?
                  WHERE `order`.oid = ?;";
        $this->queryFetchAll($query, $queryParams);
    }

    /**
     * Запрос на редактирование деталей заказа
     * @param array $params
     */
     public function orderItemEdit($params = [])
     {
        $this->logger->logEvent('edit orderItem', __FILE__, __LINE__, __FUNCTION__);
        $queryParams = $params;

        $query = "UPDATE `order_item_rel` SET `quantity` = ? WHERE `oid` = ? and `item_id` = ?;";
        $this->queryFetchAll($query, $queryParams);
    }

    /**
     * Запрос на редактирование данных клиента
     * @param array $params
     */
    public function clientEdit($params = [])
    {
        $this->logger->logEvent('edit client', __FILE__, __LINE__, __FUNCTION__);
        $queryParams = $params;
        $query = "UPDATE `client` SET `firstname` = ? ,`lastname`=?,`birthdate`=? ,`address`=? WHERE `ID`=?";
        $this->queryFetchAll($query, $queryParams);
    }

    /**
     * Запрос на редактирование данных в каталоге
     * @param array $params
     */
    public function catalogItemEdit($params = [] )
    {
        $this->logger->logEvent('edit catalogItem', __FILE__, __LINE__, __FUNCTION__);
        $queryParams = $params;
        $query = "UPDATE `catlog_item` SET `item_name` = ?, `description` = ?, `price`=? WHERE `item_id` = ?;";
        $this->queryFetchAll($query, $queryParams);
    }

    /**
     * Запрос на удаление заказа
     * @param array $params
     */
    public function orderDelete($params = [] )
    {
        $this->logger->logEvent('delete order', __FILE__, __LINE__, __FUNCTION__);
        $queryParams = $params;
        $query = "DELETE FROM `order` WHERE `order`.oid = ?";
        $this->queryFetchAll($query, $queryParams);
    }

    /**
     * Запрос на удаление деталей заказа
     * @param array $params
     */
    public function orderItemDelete($params = [])
    {
        $this->logger->logEvent('delete orderItem', __FILE__, __LINE__, __FUNCTION__);
        $queryParams = $params;
        $query = "DELETE FROM `order_item_rel`
        WHERE `order_item_rel`.`oid` = ? and `order_item_rel`.`item_id` = ?;";
        $this->queryFetchAll($query, $queryParams);
    }

    /**
     * Запрос на удаление данных клиента
     * @param array $params
     */
    public function clientDelete($params = [])
    {
         $this->logger->logEvent('delete client', __FILE__, __LINE__, __FUNCTION__);
         $queryParams = $params;
         $query = "DELETE FROM `client` WHERE `ID` = ?;";
         $this->queryFetchAll($query, $queryParams);
    }

    /**
     * Запрос на удаление данных из каталога
     * @param array $params
     */
    public function catalogItemDelete($params = [] )
    {
        $this->logger->logEvent('delete catalogItem', __FILE__, __LINE__, __FUNCTION__);
        $queryParams = $params;
        $query = "DELETE FROM `catlog_item` WHERE `item_id`=?;";
        $this->queryFetchAll($query, $queryParams);
    }

    /**
     * Запрос с конкатенацией на нулевое значение
     * в таблице клиентов
     * @return array
     */
    public function listNames()
    {
        $this->logger->logEvent('list concat', __FILE__, __LINE__, __FUNCTION__);
        $query = "SELECT ID, CONCAT(`client`.`lastname`, ' ', `client`.`firstname`) as name
        FROM `client`";
        $queryParams = [];
        $data = $this->queryFetchAll($query, $queryParams);
        return $data;
    }

    /**
     * Запрос на выдачу данных о клиенте по его ID
     * @param $params
     * @return array
     */
    public function byIDClient($params)
    {
        $this->logger->logEvent('list clientID', __FILE__, __LINE__, __FUNCTION__);
        $query = "SELECT *
                    FROM `client` WHERE ID = ?";
        $queryParams = $params;
        $data = $this->queryFetchAll($query, $queryParams);

        return $data;
    }

    /**
     * Запрос на выдачу каталога по имени
     * @param $name
     * @return array
     */
    public function catalogByNameListing($name)
    {
        $this->logger->logEvent('list calatogByName', __FILE__, __LINE__, __FUNCTION__);
        $query = "SELECT `item_name`, `item_id`
                    FROM `catlog_item`
                    WHERE item_name = ?";
        $queryParams = $name;
        $data = $this->queryFetchAll($query, $queryParams);

        return $data;
    }

    /**
     * Запрос на выдачу каталога по ID
     * @param $name
     * @return array
     */
    public function listCatalogByID($name)
    {
        $this->logger->logEvent('list catalogByID', __FILE__, __LINE__, __FUNCTION__);
        $query = "SELECT *
                    FROM `catlog_item`
                    WHERE item_id = ?";
        $queryParams = $name;
        $data = $this->queryFetchAll($query, $queryParams);

        return $data;
    }

    /**
     * Запрос на выдачу каталога
     * @return array
     */
    public function catalogList()
    {
        $this->logger->logEvent('list catalog', __FILE__, __LINE__, __FUNCTION__);
        $query = "SELECT `item_name`, `item_id`
                    FROM `catlog_item`";
        $queryParams = [];
        $data = $this->queryFetchAll($query, $queryParams);

        return $data;
    }

    /**
     * Запрос на выдачу заказа по ID
     * @param array $params
     * @return array
     */
    public function orderInfoById(  $params = []  )
    {
        $this->logger->logEvent('list orderByID', __FILE__, __LINE__, __FUNCTION__);
        $queryOrder = "SELECT *
                        FROM `order`
                        WHERE `order`.oid = ?";
        $this->listnames();
        $data = $this->queryFetchAll($queryOrder, $params);

        return $data;
    }

    /**
     * Запрос на наличие деталей заказа
     * @param array $params
     * @return array
     */
    public function checkOrderItem(  $params = []  )
    {
        $this->logger->logEvent('check orderItem', __FILE__, __LINE__, __FUNCTION__);
        $queryOrder = "SELECT *
                        FROM `order_item_rel`
                        WHERE `order_item_rel`.oid = ? and `order_item_rel`.item_id = ?";

        return $this->queryFetchAll($queryOrder, $params);
    }

    /**
     * Запрос на проверку данных о клиенте по его ID
     * @param array $params
     * @return array
     */
    public function clientCheck(  $params = []  )
    {
        $this->logger->logEvent('check clientByID', __FILE__, __LINE__, __FUNCTION__);
        $queryOrder = "SELECT *
                        FROM `client`
                        WHERE `client`.ID = ?";

        return $this->queryFetchAll($queryOrder, $params);
    }

    /**
     * Запрос на проверку перед удаление заказа
     * @param array $params
     * @return bool
     */
    public function deleteOrderCheck($params = [])
    {
        $this->logger->logEvent('check order', __FILE__, __LINE__, __FUNCTION__);
        $queryParams = $params;
        $query = "SELECT *
                    FROM `order_item_rel`
                    WHERE `order_item_rel`.oid = ?";

        $query2 = "SELECT *
                    FROM `order`
                    WHERE `order`.oid = ?";

        return empty($this->queryFetchAll($query, $queryParams)) && !empty($this->queryFetchAll($query2, $queryParams));
    }

    /**
     * Запрос на проверку деталей заказа перед удаление
     * @param array $params
     * @return bool
     */
    public function deleteOrderItemCheck($params = [])
    {
        $this->logger->logEvent('check orderItem', __FILE__, __LINE__, __FUNCTION__);
        $queryParams = $params;
        $query = "SELECT *
                    FROM `order_item_rel`
                    WHERE `order_item_rel`.oid = ? and `order_item_rel`.item_id = ?";

        return !empty($this->queryFetchAll($query, $queryParams));
    }

    /**
     * Запрос на проверку данных о клиенте перед удалением
     * запрос в 2 таблицы, воизбежании аномалий
     * @param array $params
     * @return bool
     */
    public function deleteClientCheck($params = [])
    {
        $this->logger->logEvent('check clientByID', __FILE__, __LINE__, __FUNCTION__);
        $queryParams = $params;
        $query = "SELECT *
                    FROM `client`
                    WHERE `client`.ID = ?";

        $query2 = "SELECT *
            FROM `order`
            WHERE `order`.client_id = ?";

        return !empty($this->queryFetchAll($query, $queryParams)) && empty($this->queryFetchAll($query2, $queryParams));
    }

    /**
     * Запрос на проверку каталога перед редактированием
     * @param array $params
     * @return array
     */
    public function checkEditCatalogItem(  $params = []  )
    {
        $this->logger->logEvent('check catalog', __FILE__, __LINE__, __FUNCTION__);
        $queryOrder = "SELECT *
                        FROM `catlog_item`
                        WHERE `catlog_item`.item_id = ? ";

        return $this->queryFetchAll($queryOrder, $params);
    }

    /**
     * Запрос на проверку каталога перед удалением
     * Запрос в 2 таблицы, воизбежании аномалий
     * @param array $params
     * @return bool
     */
    public function deleteCatalogItemCheck($params = [])
    {
        $this->logger->logEvent('check catalog', __FILE__, __LINE__, __FUNCTION__);
        $queryParams = $params;
        $query = "SELECT *
                    FROM `catlog_item`
                    WHERE `catlog_item`.item_id = ?";

        $query2 = "SELECT *
                    FROM `order_item_rel`
                    WHERE `order_item_rel`.item_id = ?";

        return !empty($this->queryFetchAll($query, $queryParams)) && empty($this->queryFetchAll($query2, $queryParams));
    }

}
