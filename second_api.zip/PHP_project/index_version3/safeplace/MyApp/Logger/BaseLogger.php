<?php

namespace MyApp\Logger;

abstract class BaseLogger implements LoggerInterface
{
    protected int $type; // тип логера

    /**
     * При создании класса пишем ему тип в свойство
     * BaseLogger constructor.
     * @param int $type
     */
    public function __construct(int $type)
    {
        $this->type = $type;
    }

    /**
     * Геттер на получение типа
     * @return int
     */
    public function getType(): int
    {
        return $this->type;
    }

    /**
     * Подготовка для записи в лог
     * @param $message
     * @param $file
     * @param $line
     * @param $function
     * @return array
     */
    protected final function prepareLogRecord( $message, $file, $line, $function ): array
    {
        return [
            'message' => $message,
            'file' => $file,
            'line' => $line,
            'function' => $function,
            'user' => 1,
            'date' => date('d.m.Y H:m:s', time())
        ];
    }

    /**
     * Информация о текущей записи лога в текстовой форме
     */
    protected function getLogTextVerbose( array $lr ): string
    {
        return "LOG type(".$this->getType().") [".$lr['date']."]: ".$lr['message']." at ".$lr['file']." line ".$lr['line'].PHP_EOL;
    }
}
