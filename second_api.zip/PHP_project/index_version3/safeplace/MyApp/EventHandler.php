<?php

namespace MyApp;

use Twig\Evironment;
use Twig\Loader\FilesystemLoader;
use MyApp\Controller;
use MyApp\Logger\LoggerInterface;
use PDO;
use Exception;

require '../vendor/autoload.php';

class EventHandler
{
    private string $page;
    private PDO $dbh;
    protected LoggerInterface $logger;
    protected $loader;
    protected $twig;
    protected $template;
    protected $orders;
    protected int $getn;

    protected $resultId = 0;

    protected $resultQuery = [];
    protected $paramsFilters = [];
    protected $paramsQuery = [];
    protected $errorsQuery = [];

    protected $errorNotFound = ['description' => "По вашему запросу ничего не найдено"];
    protected $errorIncorrect = ['description' => "Неверные данные"];

    public function __construct(array $dbSettings, LoggerInterface $logger)
    {
        $this->loader = new \Twig\Loader\FilesystemLoader($_SERVER['DOCUMENT_ROOT'].'/index_version3/safeplace/Myapp/Templates');
        $this->twig = new \Twig\Environment($this->loader);
        $this->logger = $logger;
        $this->page = (array_key_exists('page', $_GET)) ? $_GET['page'] : 'default';
        //Подключение бд
        $this->initDB( $dbSettings['connectionString'], $dbSettings['dbUser'], $dbSettings['dbPwd'] );
    }

    private function initDB( string $connectionString, string $dbUser, string $dbPwd )
    {
        // создание подключения через connection_string с указанием типа базы
        $this->dbh = new PDO( $connectionString, $dbUser, $dbPwd );
        $this->dbh->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $this->dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $this->logger->logEvent('Connected to DB!', __FILE__, __LINE__, __FUNCTION__);
    }

    /**
     * call handler to process request
     */
    public function run()
    {
    	$this->orders = new Controller\OrderClass( $this->dbh, $this->logger );
        try {
            $this->logger->logEvent('curpage: '.$this->page, __FILE__, __LINE__, __FUNCTION__);

            switch ( $this->page ) {
                case 'listorders':
                    $this->template = $this->twig->load($this->page.'.html');
                    if (count($_GET) == 1) {
                    	
                        if (array_key_exists("client_id",$_POST) && $_POST["client_id"] > 0) {
                            if (!empty($_POST["client_id"]) && is_int((int)$_POST["client_id"])  ) {
                                $this->paramsFilters["client_id"] =  $_POST["client_id"];
                            } else {
                                $this->errorsQuery[] = $this->errorNotFound;
                            }
                        }

                        if (array_key_exists("order_num",$_POST)) {
                            if (!empty($_POST["order_num"]) && is_string($_POST["order_num"])) {
                                $this->paramsFilters["order_num"] =  $_POST["order_num"];
                            }
                        }

                        if (array_key_exists("order_date",$_POST)) {
                            if (!empty($_POST["order_date"])) {
                                $this->paramsFilters["order_date"] =  $_POST["order_date"];
                            }
                        }

                        if (!empty($_POST["items_per_page"]) && array_key_exists("items_per_page",$_POST)) {
                            if ($_POST["items_per_page"] > 0) {
                                $this->paramsFilters["items_per_page"] = $_POST["items_per_page"];
                            } else {
                                $this->errorsQuery[] = $this->errorNotFound;
                            }
                        } else {
                            $this->paramsFilters["items_per_page"] = 30;
                        }

                        if (!empty($_POST["page_number"]) && array_key_exists("page_number",$_POST)) {
                            if (is_int($_POST["page_number"]) && $_POST["page_number"] > 0) {
                                $this->paramsFilters["page_number"] =  $_POST["page_number"];
                            } else {
                                $this->errorsQuery[] = $this->errorNotFound;

                            }
                        } else {
                            $this->paramsFilters["page_number"] = 1;
                        }

                        if (empty($this->errorsQuery)) {
                            $this->resultQuery = $this->orders->listing($this->paramsQuery, $this->paramsFilters);
                        }

                        break;
                    } else {
                        $this->errorsQuery[] = $this->errorNotFound;
                        break;
                    }

                case 'orderinfo':
                    $this->template = $this->twig->load('orderinfo' . '.html');
                    if (count($_GET) == 2 && array_key_exists('oid', $_GET)) {
                        if (!empty($_GET["oid"]) && is_int((int)$_GET["oid"])  && $_GET["oid"] > 0) {
                            $this->paramsQuery["oid"] =  $_GET["oid"];
                        } else {
                            $this->errorsQuery[] = $this->errorNotFound;
                        }

                        if (empty($this->errorsQuery)) {
                            $this->resultQuery = $this->orders->infoOrder($this->paramsQuery);
                        }

                        break;
                    } else {
                        $this->errorsQuery[] = $this->errorNotFound;
                        break;
                    }

                case 'listclients':
                    $this->template = $this->twig->load('listclients'.'.html');
                    if (count($_GET) == 1) {
                        if (!empty($_POST["lastname"]) && array_key_exists("lastname",$_POST)){
                            if ( is_string($_POST["lastname"]) ){
                                $this->paramsFilters["lastname"] = $_POST["lastname"];
                            }else{
                                $this->errorsQuery[] = $this->errorNotFound;
                            }
                        }

                        if (!empty($_POST["birthyear"]) && array_key_exists("birthyear",$_POST)) {
                            if ( is_string($_POST["birthyear"])) {
                                $this->paramsFilters["birthyear"] = $_POST["birthyear"];
                            } else {
                                $this->errorsQuery[] = $this->errorNotFound;
                            }
                        }

                        if (empty($this->errorsQuery)) {
                            $this->resultQuery = $this->orders->clientsListing($this->paramsQuery, $this->paramsFilters);
                        }

                        break;
                    } else {
                        $this->errorsQuery[] = $this->errorNotFound;
                    }

                    break;


                case 'catalog':
                    $this->template = $this->twig->load('catalog'.'.html');

                    if (count($_GET) == 1) {
                        if (!empty($_POST["item_name"]) && array_key_exists("item_name",$_POST)) {
                            if (is_string($_POST["item_name"]) ) {
                                $this->paramsFilters["item_name"] =  $_POST["item_name"];
                            } else {
                                $this->errorsQuery[] = $this->errorNotFound;
                            }
                        }

                        if (!empty($_POST["description"]) && array_key_exists("description",$_POST)) {
                            if ( is_string($_POST["description"])) {
                                $this->paramsFilters["description"] =  $_POST["description"];
                            } else {
                                $this->errorsQuery[] = $this->errorNotFound;
                            }
                        }

                        if (!empty($_POST["minprice"]) && array_key_exists("minprice",$_POST)) {
                            $this->paramsFilters["minprice"] =  $_POST["minprice"];
                        }

                        if (!empty($_POST["maxprice"]) && array_key_exists("maxprice",$_POST)) {
                                $this->paramsFilters["maxprice"] =  $_POST["maxprice"];
                        }

                        if (empty($this->errorsQuery)) {
                            $this->resultQuery = $this->orders->catalogListing($this->paramsQuery, $this->paramsFilters);
                        }

                        break;
                    } else {
                        $this->errorsQuery[] = $this->errorNotFound;
                        break;
                    }

                case 'addorder':
                    $this->template = $this->twig->load('addorder'.'.html');
                    $this->resultQuery['names']=$this->orders->listNames();

                    if (array_key_exists('ordernum', $_POST) &&
                        array_key_exists('order_date', $_POST) &&
                        array_key_exists('client', $_POST)) {

                        if (!empty($_POST["ordernum"]) ) {
                            array_push($this->paramsQuery, $_POST["ordernum"]);
                        } else {
                            $this->errorsQuery[] = $this->errorNotFound;
                        }

                        if (!empty($_POST["order_date"])) {
                            array_push($this->paramsQuery, $_POST["order_date"]);
                        } else {
                            $this->errorsQuery[] = $this->errorNotFound;
                        }

                        if (!empty($_POST["client"])&&$_POST["client"]!='0') {
                            array_push($this->paramsQuery, $_POST["client"]);
                        } else {
                            $this->errorsQuery[] = $this->errorNotFound;
                        }

                        if (empty($this->errorsQuery)) {
                            $this->resultId = $this->orders->orderAdd($this->paramsQuery);
                        }

                        break;
                    } else if (!count($_POST)==0) {
                        $this->errorsQuery[] = $this->errorIncorrect;
                        break;
                    }

                    break;

				case 'addorderitem':
                	if (count($_GET) == 2 &&
                        array_key_exists('oid', $_GET) &&
                        is_int((int)$_GET['oid'])) {

                        $this->template = $this->twig->load('addorderitem'.'.html');
                        $this->resultQuery['catalog']=$this->orders->catalogList();
                        $this->resultQuery['oid']=$_GET['oid'];

                        if (array_key_exists('quantity', $_POST) &&
                            array_key_exists('item_id', $_POST)) {
                                array_push($this->paramsQuery, $_GET["oid"]);

                                if (!empty($_POST["item_id"]) && $_POST["item_id"]!='0') {
                                    array_push($this->paramsQuery, $_POST["item_id"]);
                                } else {
                                    $this->errorsQuery[] = $this->errorNotFound;
                                }

                                if (!empty($_POST["quantity"]) ) {
                                    array_push($this->paramsQuery, $_POST["quantity"]);
                                } else {
                                    $this->errorsQuery[] = $this->errorNotFound;
                                }

                                if (empty($this->errorsQuery)) {
                                    $this->resultId = $this->orders->orderItemAdd($this->paramsQuery);
                                }

                                break;
                    }else if (!count($_POST)==0) {
                        $this->errorsQuery[] = $this->errorIncorrect;
                        break;
                    }
                    } else {
                    	$this->errorsQuery[] = $this->errorNotFound;
                    }

                    break;

                case 'addclient':
                    $this->template = $this->twig->load('addclient'.'.html');
                    
                    if (array_key_exists('lastname', $_POST) &&
                    	array_key_exists('firstname', $_POST) &&
                    	array_key_exists('birthdate', $_POST) &&
                        array_key_exists('address', $_POST) ) {

                            if (!empty($_POST["lastname"])) {
                                array_push($this->paramsQuery, $_POST["lastname"]);
                            } else {
                                $this->errorsQuery[] = $this->errorNotFound;
                            }

                            if (!empty($_POST["firstname"])) {
                                array_push($this->paramsQuery, $_POST["firstname"]);
                            } else {
                                $this->errorsQuery[] = $this->errorNotFound;
                            }

                            if (!empty($_POST["birthdate"])) {
                                array_push($this->paramsQuery, $_POST["birthdate"]);
                            } else {
                                $this->errorsQuery[] = $this->errorNotFound;
                            }
                            array_push($this->paramsQuery, $_POST["address"]);

                            if (empty($this->errorsQuery)) {
                                $this->resultId = $this->orders->clientsAdd($this->paramsQuery);
                            }
                            break;

                    }else if (!count($_POST)==0){
                        $this->errorsQuery[] = $this->errorIncorrect;
                        break;
                    }
                    break;

                case 'addcatalogitem':
                    $this->template = $this->twig->load('addcatalogitem'.'.html');
                  
                    if (array_key_exists('item_name', $_POST) &&
                    	array_key_exists('description', $_POST) &&
                    	array_key_exists('price', $_POST) ) {

                        if (!empty($_POST["item_name"]) &&
                            is_null($this->orders->catalogByNameListing([$_POST["item_name"]])[0])) {

                        	array_push($this->paramsQuery, $_POST["item_name"]);
                        } else {
                            $this->errorsQuery[] = $this->errorNotFound;
                        }

                        if (!empty($_POST["description"])) {
                        	array_push($this->paramsQuery, $_POST["description"]);
                        } else {
                            $this->errorsQuery[] = $this->errorNotFound;
                        }

                        if (!empty($_POST["price"])) {
                        	array_push($this->paramsQuery, $_POST["price"]);
                        } else {
                            $this->errorsQuery[] = $this->errorNotFound;
                        }

                        if (empty($this->errorsQuery)) {
                            $this->orders->catalogItemAdd($this->paramsQuery);
                            $this->resultId = 1;
                        }
                        break;

                    } else if (!count($_POST)==0) {
                        $this->errorsQuery[] = $this->errorIncorrect;
                        break;
                    }
                    break;

                case 'editorder':
                    $this->template = $this->twig->load('editorder'.'.html');
                    
                    if ( count($_GET) == 2 &&
                        array_key_exists('oid', $_GET) &&
                        (int)($_GET["oid"]) > 0 &&
                        is_int((int)$_GET["oid"]) ) {

                        if (!count($_POST) == 0){
                            if (!empty($_POST["order_num"]) && is_string($_POST["order_num"]) ) {
                                array_push($this->paramsQuery, $_POST["order_num"]);
                            } else {
                                $this->errorsQuery[] = $this->errorNotFound;
                            }

                            if (!empty($_POST["date"])) {
                                array_push($this->paramsQuery, $_POST["date"]);
                            } else {
                                $this->errorsQuery[] = $this->errorNotFound;
                            }

                            if (!empty($_POST["client"]) && is_int((int)$_POST["client"]) ) {
                                array_push($this->paramsQuery, $_POST["client"]);
                            } else {
                                $this->errorsQuery[] = $this->errorNotFound;
                            }

                            array_push($this->paramsQuery, $_GET["oid"]);

                            if (!empty($this->orders->orderInfoById([$_GET["oid"]]))) {
                                $this->orders->orderEdit($this->paramsQuery);
                                $this->resultId = $this->paramsQuery["oid"];
                            } else {
                                $this->errorsQuery[] = $this->errorNotFound;
                            }

                        } else {
                        	$this->resultQuery['names']=$this->orders->listNames();
                        	$ord =$this->orders->orderInfoById([$_GET["oid"]]);

                        	if (!empty($ord)) {
                                $this->resultQuery['data']=$ord;
                            } else {
                                $this->errorsQuery[] = $this->errorNotFound;
                            }
                        }
                    break;
                    }
                    else{
                        $this->errorsQuery[] = $this->errorNotFound;
                        break;
                    }

                case 'editorderitem':
                    $this->template = $this->twig->load('editorderitem'.'.html');

                    if (count($_GET) == 3 &&
                        array_key_exists('oid', $_GET) &&
                        (int)$_GET["oid"] > 0 &&
                        is_int((int)$_GET["oid"]) &&
                        array_key_exists('itemid', $_GET) &&
                        (int)$_GET["itemid"] > 0 &&
                        is_int((int)$_GET["itemid"])) {

                        if (!count($_POST) == 0){
                            if (!empty($_POST["quantity"]) && is_int((int)$_POST["quantity"]) ) {
                                array_push($this->paramsQuery, $_POST["quantity"]);
                            } else {
                                $this->errorsQuery[] = $this->errorNotFound;
                            }

                            array_push($this->paramsQuery, $_GET["oid"]);
                            array_push($this->paramsQuery, $_GET["itemid"]);

                            if (!empty($this->orders->checkOrderItem([$_GET["oid"], $_GET["itemid"]]))) {
                                $this->orders->orderItemEdit($this->paramsQuery);
                                $this->resultId = 1;
                            } else {
                                $this->errorsQuery[] = $this->errorNotFound;
                            }
                        } else {
                            $ord = $this->orders->checkOrderItem([$_GET["oid"], $_GET["itemid"]]);
                            if (!empty($ord)) {
                                $this->resultQuery["data"] = $ord;
                                $this->resultQuery["item"] = $this->orders->listCatalogByID([ $_GET["itemid"]]);
                            } else {
                                $this->errorsQuery[] = $this->errorNotFound;
                            }
                        }
                        break;
                    }
                    else{
                        $this->errorsQuery[] = $this->errorNotFound;
                        break;
                    }

                case 'editclient':
                    $this->template = $this->twig->load('editclient'.'.html');
                    
                    if (count($_GET) == 2 &&
                        array_key_exists('clientid', $_GET) &&
                        $_GET["clientid"] > 0 &&
                        is_int((int)$_GET["clientid"])) {

                        if (!count($_POST) == 0) {
                            if (!empty($_POST["firstname"])) {
                                array_push($this->paramsQuery, $_POST["firstname"]);
                            } else {
                                $this->errorsQuery[] = $this->errorNotFound;
                            }

                            if (!empty($_POST["lastname"])) {
                                array_push($this->paramsQuery, $_POST["lastname"]);
                            } else {
                                $this->errorsQuery[] = $this->errorNotFound;
                            }

                            if (!empty($_POST["birthdate"]) ){
                                array_push($this->paramsQuery, $_POST["birthdate"]);
                            }else{
                                $this->errorsQuery[] = $this->errorNotFound;
                            }
                            
                            if (!empty($_POST["birthdate"]) ) {
                               array_push($this->paramsQuery, $_POST["address"]);
                            } else {
                                array_push($this->paramsQuery, NULL);
                            }

                            array_push($this->paramsQuery, $_POST["address"]);
                            array_push($this->paramsQuery, (int)$_GET["clientid"]);

                            if (!empty($this->orders->clientCheck([$_GET["clientid"]]))) {
                                $this->orders->clientEdit($this->paramsQuery);
                                $this->resultId = 1;
                            } else {
                                $this->errorsQuery[] = $this->errorNotFound;
                            }
                        } else {
                        	$ord =$this->orders->byIDClient([$_GET["clientid"]]);
                            if (!empty($ord)) {
                                $this->resultQuery["client"] = $ord;
                            } else {
                                $this->errorsQuery[] = $this->errorNotFound;
                            }
                        }

                        break;
                    }
                    else{
                        $this->errorsQuery[] = $this->errorNotFound;
                        break;
                    }

                case 'editcatalogitem':
                    $this->template = $this->twig->load('editcatalogitem'.'.html');
                    if (count($_GET) == 2 &&
                        array_key_exists('itemid', $_GET) &&
                        $_GET["itemid"] > 0 &&
                        is_int((int)$_GET["itemid"])) {

                        if (!count($_POST) == 0) {
                            if (!empty($_POST["item_name"])) {
                                array_push($this->paramsQuery, $_POST["item_name"]);
                            } else {
                                $this->errorsQuery[] = $this->errorNotFound;
                            }

                            if (!empty($_POST["description"])) {
                                array_push($this->paramsQuery, $_POST["description"]);
                            } else {
                                $this->errorsQuery[] = $this->errorNotFound;
                            }

                            if (!empty($_POST["price"]) && is_int((int)$_POST["price"]) &&
                                (int)$_POST["price"]>0) {

                                array_push($this->paramsQuery, $_POST["price"]);
                            } else {
                                $this->errorsQuery[] = $this->errorNotFound;
                            }

                            array_push($this->paramsQuery, $_GET["itemid"]);

                            if (!empty($this->orders->listCatalogByID([$_GET["itemid"]]))) {
                                $this->orders->catalogItemEdit($this->paramsQuery);
                                $this->resultId = 1;
                            } else {
                                $this->errorsQuery[] = $this->errorNotFound;
                            }
                        } else {
                        	$ord = $this->orders->listCatalogByID([$_GET["itemid"]]);
                            if (!empty($ord)) {
                                $this->resultQuery["data"] = $ord;
                            } else {
                                $this->errorsQuery[] = $this->errorNotFound;
                            }
                        }

                        break;
                    }
                    else{
                        $this->errorsQuery[] = $this->errorNotFound;
                        break;
                    }

                case 'deleteorder':
                    $this->template = $this->twig->load('empty'.'.html');
                    
                    if (count($_GET) == 2 &&
                        array_key_exists('oid', $_GET) &&
                        $_GET["oid"] > 0 &&
                        is_int((int)$_GET["oid"])) {

                        array_push($this->paramsQuery, $_GET["oid"]);
                       
                        if ($this->orders->deleteOrderCheck($this->paramsQuery)) {
                            $this->orders->orderDelete($this->paramsQuery);
                            $this->resultId = 1;
                        } else {
                            $this->errorsQuery[] = $this->errorNotFound;
                        }

                        break;
                    } else {
                        $this->errorsQuery[] = $this->errorNotFound;
                        break;
                    }

                case 'deleteorderitem':
                    $this->template = $this->twig->load('empty'.'.html');
                    if (count($_GET) == 3 &&
                        array_key_exists('oid', $_GET) &&
                        $_GET["oid"] > 0 &&
                        is_int((int)$_GET["oid"]) &&
                        array_key_exists('itemid', $_GET) &&
                        $_GET["itemid"] > 0 &&
                        is_int((int)$_GET["itemid"])) {

                        array_push($this->paramsQuery, $_GET["oid"]);
                        array_push($this->paramsQuery, $_GET["itemid"]);

                        if ($this->orders->deleteOrderItemCheck($this->paramsQuery)) {
                            $this->orders->orderItemDelete($this->paramsQuery);
                            $this->resultId = 1;
                        } else {
                            $this->errorsQuery[] = $this->errorNotFound;
                        }

                        break;
                    } else{
                        $this->errorsQuery[] = $this->errorNotFound;
                        break;
                    }

                case 'deleteclient':
                    $this->template = $this->twig->load('empty'.'.html');
                    if (count($_GET) == 2 &&
                        array_key_exists('clientid', $_GET) &&
                        $_GET["clientid"] > 0 &&
                        is_int((int)$_GET["clientid"])) {

                        array_push($this->paramsQuery, $_GET["clientid"]);

                        if ($this->orders->deleteClientCheck($this->paramsQuery)) {
                            $this->orders->clientDelete($this->paramsQuery);
                            $this->resultId = 1;
                        } else {
                            $this->errorsQuery[] = $this->errorNotFound;
                        }
                        break;
                    } else{
                        $this->errorsQuery[] = $this->errorNotFound;
                        break;
                    }
          
                case 'deletecatalogitem':
                    $this->template = $this->twig->load('empty'.'.html');
                    if (count($_GET) == 2 &&
                        array_key_exists('itemid', $_GET) &&
                        $_GET["itemid"] > 0 &&
                        is_int((int)$_GET["itemid"])) {

                        array_push($this->paramsQuery, $_GET["itemid"]);

                        if ($this->orders->deleteCatalogItemCheck($this->paramsQuery)) {
                            $this->orders->catalogItemDelete($this->paramsQuery);
                            $this->resultId = 1;
                        } else {
                            $this->errorsQuery[] = $this->errorNotFound;
                        }
                        break;
                    } else{
                        $this->errorsQuery[] = $this->errorNotFound;
                        break;
                    }

                default:
                 	$this->template = $this->twig->load('empty'.'.html');
                    $this->errorsQuery[] = $this->errorNotFound;
                    break;
            }
        }
        catch (Exception $e) {
            $this->logger->logEvent($e->getMessage(), $e->getFile(), $e->getLine(), $e->getTraceAsString());
            echo json_encode([]);
        }
       
        $this->resultQuery["errors"] = $this->errorsQuery;
        $this->resultQuery["resultId"] = $this->resultId;
        echo $this->template->render($this->resultQuery);
    }

}